(function ($) {
    $.processAjaxRequest = function ($options) {
        if ($options === undefined || typeof $options !== "object") {
            console.error("INVALID PROPERTY EXCEPTION: No properties found");
            return;
        }

        var $url = $options.url,
            $type = ($options.type !== undefined) ? $options.type : "post",
            $data = ($options.data !== undefined) ? $options.data : {},
            $csrfParam = yii.getCsrfParam(),
            $csrfToken = yii.getCsrfToken();

        if ($url === undefined) {
            console.error("INVALID PROPERTY EXCEPTION: url not found.");
            return;
        }
        
        if (typeof $data === "object") {
            $data[$csrfParam] = $csrfToken;
        } else {
            $data += "&" + $csrfParam + "=" + $csrfToken;
        }
        
        var $defaults = {
            url: $url,
            type : $type,
            data: $data,
            cache: false,
            success: function ($response, $textStatus, $xhr) {
                if ($options.successcallback !== undefined) {
                    $options.successcallback.call(this, $response, $textStatus, $xhr);
                }
            },
            error: function ($jqXHR, $textStatus, $errorThrown) {
                if ($options.errorcallback !== undefined) {
                    $options.errorcallback.call(this, $jqXHR, $textStatus, $errorThrown);
                }
            },
            complete: function ($jqXHR, $textStatus) {
                if ($options.completecallback !== undefined) {
                    $options.completecallback.call(this, $jqXHR, $textStatus);
                }
            }
        };
        
        //$.extend($defaults, $ajaxParams);
        var $xhr = $.ajax($defaults);
        
        return $xhr;
    };
    
    $.showModal = function ($config) {
        
        if($("#myModal")){
            $("#myModal").remove();
        }
        
        if ($config === undefined) {
            $config = {};
        }
        
        var $modalHeading = ($config.modalHeading !== undefined) ? $config.modalHeading : "";
        var $modalBody = ($config.modalBody !== undefined) ? $config.modalBody : "";
        var $footerButtons = ($config.footerButtons !== undefined) ? $config.footerButtons : "";
        
        html = "<div class=\"modal fade\" id=\"myModal\">";
        html += "<div class=\"modal-dialog\">";
        html += "<div class=\"modal-content\">";
        html += "<div class=\"modal-header\">";
        html += "<h4 class=\"modal-title\">" + $modalHeading + "</h4>";
        html += "<button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>";
        html += "</div>";
        html += "<div class=\"modal-body\">" + $modalBody + "</div>";
        html += "<div class=\"modal-footer\">";
        html += "<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>";
        html += $footerButtons;
        html += "</div>";
        html += "</div>";
        html += "</div>";
        html += "</div>";
        
        $("body").append(html);
        $("#myModal").modal("show");
    };
})(jQuery);